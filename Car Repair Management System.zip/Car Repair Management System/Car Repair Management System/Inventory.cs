﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Repair_Management_System
{
    class Inventory
    {
        public int price;
        public int Invid;

        public void MenuInventory()
        {
            Console.WriteLine("Menu : (Inventory)");
            Console.WriteLine("  Press 1 to list all Inventory ");
            Console.WriteLine("  Press 2 to add a new Inventory");
            Console.WriteLine("  Press 3 to update...");
            Console.WriteLine("  Press 4 to delete...");
            Console.WriteLine("  Press 5 return to Main Menu...");
        }
        //this is the command for displaying vehicles from inventory
        public string InventoryDisplayVehicle()
        {
            string displayQuery = "SELECT * FROM Inventory";
            return displayQuery;
        }
        //this is the sql command to insert vehicles to inventory
        public string InventoryVehicleInsert()
        {
            Console.WriteLine("Enter the Inventory ID ");
            int Inventory_Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Vehicle ID");
            int Vehicle_Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the NumberOnHand");
            string NumberOnHand = Console.ReadLine();
            Console.WriteLine("Enter the price");
            string price = Console.ReadLine();
            Console.WriteLine("Enter the cost ");
            string cost = Console.ReadLine();
            string insertQuery = "insert into dbo.Inventory(Inventory_Id,Vehicle_Id,NumberOnHand,price,cost) values ('" + Inventory_Id + "','" + Vehicle_Id + "','" + NumberOnHand + "','" + price + "','" + cost + "')";
            return insertQuery;

        }
        //this is the sqlcommand to update vehicles from inventory
        public string InventoryUpdateVehicle()
        {

            Console.WriteLine("Enter the id of the entry to be Updated");
            Invid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name you would like to change");
            price = int.Parse(Console.ReadLine());
            String updateQuery = "UPDATE Inventory SET price = '" + price + "' WHERE Inventory_Id = " + Invid + "";
            return updateQuery;
        }
        //this is the sql commands to delete vehicle from inventory
        public string InventoryDeleteVehicle()
        {

            Console.WriteLine("Enter the id of the entry to be removed");
            Invid = int.Parse(Console.ReadLine());
            String deleteQuery = "DELETE FROM Inventory WHERE Inventory_Id = " + Invid + "";
            return deleteQuery;
        }
    }
}

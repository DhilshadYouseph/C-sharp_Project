﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using System.Data;


namespace Car_Repair_Management_System
{
    class Vehicle
    {
        public int vid;


        public void MenuVehicle() // No Parameter  
        {
            Console.WriteLine("Menu : (Vehicles)");
            Console.WriteLine("  Press 1 to list all Vehicles ");
            Console.WriteLine("  Press 2 to add a new vehicle");
            Console.WriteLine("  Press 3 to update...");
            Console.WriteLine("  Press 4 to delete...");
            Console.WriteLine("  Press 5 return to Main Menu...");

        }

        /*
         This is the sql command for displaying all the vehicles
         */
        public string VehicleDisplayInfo()
        {
            string displayQuery = "SELECT * FROM Vehicle";
            return displayQuery;
        }
        //this is the sql command to insert a new vehicle
        public string VehicleInfoInsert()
        {
            Console.WriteLine("Vehicle Id  : ");
            int Vehicle_Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Make  : ");
            string Vehicle_Make = Console.ReadLine();
            Console.WriteLine("Model  : ");
            string Vehicle_Model = Console.ReadLine();
            Console.WriteLine("Year  : ");
            string Manufactured_Year = Console.ReadLine();
            Console.WriteLine("New/Used  : ");
            string Used = Console.ReadLine();
            string insertQuery = "insert into dbo.Vehicle(Vehicle_Id,Make,Model,Year,New_Used) values ('" + Vehicle_Id + "','" + Vehicle_Make + "','" + Vehicle_Model + "','" + Manufactured_Year + "','" + Used + "')";
            return insertQuery;

        }
        //this is the sql command to update details of vehicles
        public string VehicleUpdateDetails()
        {
            
            string vehiclemake;
            Console.WriteLine("Enter the id of the entry to be Updated");
            vid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Make you would like to change");
            vehiclemake = Console.ReadLine();
            Console.WriteLine("Enter the Model you would like to change");
            string vehiclemodel = Console.ReadLine();
            string updateQuery = "UPDATE Vehicle SET Make = '" + vehiclemake + "' ,Model = '" + vehiclemodel + "' WHERE Vehicle_Id = " + vid + "";
            return updateQuery;
        }
        //this is the sql command to delete a vehicle from vehicle table
        public string VehicleDelete()
        {
            Console.WriteLine("Enter the id of the entry to be removed");
            vid = int.Parse(Console.ReadLine());
            string deleteQuery = "DELETE FROM Vehicle WHERE Vehicle_Id = " + vid + "";
            return deleteQuery;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

/*
 [D:\CAR REPAIR MANAGEMENT SYSTEM\CAR REPAIR MANAGEMENT SYSTEM\BIN\DEBUG\DATABASE\database.MDF]
 */
namespace Car_Repair_Management_System
{
    


    class Program
    {
        static void Main(string[] args)
        {
            //creating objects for vehicle, inventory and repair class
            Vehicle veh = new Vehicle();
            Inventory inv = new Inventory();
            Repair rep = new Repair();

            //connecting to project.mdf
            SqlConnection sqlConnectionTodbms;
            string connectionStringTodbms = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Database\databse.mdf;Integrated Security=True";

            sqlConnectionTodbms = new SqlConnection(connectionStringTodbms);
            sqlConnectionTodbms.Open();
            Console.WriteLine("Connection Created");

            int Option1, Option2;
            bool stop = false;

            //Asking user for input
            while (!stop)
            {
                Console.WriteLine("Menu 1:");
                Console.WriteLine("  Welcome,Please choose the Command ");
                Console.WriteLine("    Press 1 to Modify Vehicles ");
                Console.WriteLine("    Press 2 to Modify Inventory");
                Console.WriteLine("    Press 3 to Modify Repair");
                Console.WriteLine("    Press 4 to exit program");
                Option1 = Convert.ToInt32(Console.ReadLine());

                try
                {
                    if (Option1 == 1)
                    {
                        veh.MenuVehicle();
                        Option2 = Convert.ToInt32(Console.ReadLine());
                        switch (Option2)
                        {
                            case 1:
                                //programme to display the vehicle details by calling vehicleDisplayInfo function from vehicle table
                                string display = veh.VehicleDisplayInfo();

                                SqlCommand command = new SqlCommand(display, sqlConnectionTodbms);
                                SqlDataReader data= command.ExecuteReader();
                                Console.WriteLine("Vehicle_Id|  Make  |  Model  |  Year  |  New/Used  ");
                                while (data.Read())
                                {
                                    Console.WriteLine("  {0  }    |  {1}   |  {2}    |   {3}  |  {4}", data.GetValue(0).ToString(), data.GetValue(1).ToString(), data.GetValue(2).ToString(), data.GetValue(3).ToString(), data.GetValue(4).ToString());

                                }
                                data.Close();
                                break;
                            //command to insert a vehicle by calling vehicleInfoInsert function from vehicle table
                            case 2:
                                string insertCommand = veh.VehicleInfoInsert();
                                SqlCommand insertCommand = new SqlCommand(insertCommand, sqlConnectionTodbms);
                                insertCommand.ExecuteNonQuery();
                                Console.WriteLine("Data Inserted");
                                break;
                            //command to edit a vehicle details by calling vehicleUpdate function from vehicle table
                            case 3:
                                string updateCommand = veh.VehicleUpdate();
                                SqlCommand updateCommand = new SqlCommand(updateCommand, sqlConnectionTodbms);
                                updateCommand.ExecuteNonQuery();
                                Console.WriteLine("Successfully updated");
                                break;
                            //command to delete a vehicle by using VehicleDelete function from vehicle table
                            case 4:
                                string deleteCommand = veh.VehicleDelete();
                                SqlCommand deleteCommand = new SqlCommand(deleteCommand, sqlConnectionTodbms);
                                deleteCommand.ExecuteNonQuery();
                                Console.WriteLine("Successfully deleted");
                                break;

                            case 5:
                                Console.WriteLine("Returned to Main Menu");
                                break;


                        }
                    }
                    //if user enter option 2, it will update changes in Inventory
                    else if (Option1 == 2)
                    {
                        inv.MenuInventory();
                        Option2 = Convert.ToInt32(Console.ReadLine());
                        switch (Option2)
                        {

                            case 1:

                                //command to display a vehicle details by calling InventoryDisplayVehicle function from inventory table
                                string displayQuery = inv.InventoryDisplayVehicle();
                                SqlCommand viewCommand = new SqlCommand(displayQuery, sqlConnectionTodbms);
                                SqlDataReader dataReader = viewCommand.ExecuteReader();
                                Console.WriteLine(" Inventory_Id  Vehicle_Id   NumberOnHand      price           cost    ");
                                while (dataReader.Read())
                                {
                                    Console.WriteLine("      {0}           {1}            {2}         {3}       {4}  ", dataReader.GetValue(0).ToString(), dataReader.GetValue(1).ToString(), dataReader.GetValue(2).ToString(), dataReader.GetValue(3).ToString(), dataReader.GetValue(4).ToString());
                                }
                                dataReader.Close();
                                break;


                            // //command to insert a vehicle details by calling InventoryVehicleInsert function to inventory table
                            case 2:

                                string insertQuery = inv.InventoryVehicleInsert();
                                
                                SqlCommand insertCommand = new SqlCommand(insertQuery, sqlConnectionTodbms);
                                insertCommand.ExecuteNonQuery();
                                Console.WriteLine("Data Inserted");
                                break;


                            //command to update a vehicle details by calling InventoryUpdateVehicle function from inventory table
                            case 3:
                                string updateQuery = inv.InventoryUpdateVehicle();
                                SqlCommand updateCommand = new SqlCommand(updateQuery, sqlConnectionTodbms);
                                updateCommand.ExecuteNonQuery();
                                Console.WriteLine("Successfully updated");
                                break;
                            //command to delete a vehicle details by calling InventoryDeleteVehicle function from inventory table
                            case 4:
                                string deleteQuery = inv.InventoryDeleteVehicle();
                                SqlCommand deleteCommand = new SqlCommand(deleteQuery, sqlConnectionTodbms);
                                deleteCommand.ExecuteNonQuery();
                                Console.WriteLine("Successfully deleted");
                                break;

                            case 5:
                                Console.WriteLine("Returned to Main Menu");
                                break;

                        }
                    }
                    //if user inputs 3. the following options will show to user
                    else if (Option1 == 3)
                    {
                        rep.MenuRepair();
                        Option2 = Convert.ToInt32(Console.ReadLine());
                        switch (Option2)
                        {
                            //command to display a vehicle details for repair by calling RepairDisplayVehicle function from repair table
                            case 1:

                                string displaysql = rep.RepairDisplayVehicle();
                                SqlCommand view = new SqlCommand(displaysql, sqlConnectionTodbms);
                                SqlDataReader dataReader = view.ExecuteReader();
                                Console.WriteLine(" Repair_Id | Inventory_Id | WhatToRepair |");
                                while (dataReader.Read())
                                {
                                    Console.WriteLine("     {0}         {1}             {2}     ", dataReader.GetValue(0).ToString(), dataReader.GetValue(1).ToString(), dataReader.GetValue(2).ToString());
                                }
                                dataReader.Close();
                                break;

                            //command to insert a vehicle details by calling VehicleRepairInsert function to repair table
                            case 2:
                                string insertCommand = rep.VehicleRepairInsert();
                                SqlCommand insertCommand = new SqlCommand(insertCommand, sqlConnectionTodbms);
                                insertCommand.ExecuteNonQuery();
                                Console.WriteLine("Data Inserted");
                                break;

                            //command to update a vehicle details by calling VehicleRepairUpdate function to repair table
                            case 3:
                                string updateCommand = rep.VehicleRepairUpdate();
                                SqlCommand updateCommand = new SqlCommand(updateCommand, sqlConnectionTodbms);
                                updateCommand.ExecuteNonQuery();
                                Console.WriteLine("Successfully updated");
                                break;

                            //command to delete a vehicle details by calling vehicleRepairDelete function from repair table
                            case 4:
                                string deleteCommand = rep.VehicleRepairDelete();
                                SqlCommand delete = new SqlCommand(deleteCommand, sqlConnectionTodbms);
                                deleteCommand.ExecuteNonQuery();
                                Console.WriteLine("Successfully deleted");
                                break;

                            case 5:
                                Console.WriteLine("Returned to Main Menu");
                                break;

                        }
                    }
                    else
                    {
                        Console.WriteLine("Program Exit");
                        stop = true;

                    }
                }

                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    
                }
            }

            sqlConnectionTodbms.Close();

        }
    }
}

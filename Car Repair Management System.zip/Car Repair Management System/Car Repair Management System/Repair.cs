﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Car_Repair_Management_System
{
    class Repair
    {
        public string WhatToRepair;
        public int Repid;


        public void MenuRepair()
        {
            Console.WriteLine("Menu : (Repair)");
            Console.WriteLine("  Press 1 to list all Repair ");
            Console.WriteLine("  Press 2 to add a new Repair");
            Console.WriteLine("  Press 3 to update...");
            Console.WriteLine("  Press 4 to delete...");
            Console.WriteLine("  Press 5 return to Main Menu...");

        }
        //this is the command to display vehicles for repair
        public string DisplayRepairVehicles()
        {
            string displayQuery = "SELECT * FROM Repair";
            return displayQuery;
        }
        //this is the command to insert vehicle for repair
        public string VehicleRepairInsert()
        {
            Console.WriteLine("Enter the Repair Id ");
            int Repair_Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the Inventory Id ");
            int Inventory_Id = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter WhatToRepair");
            string WhatToRepair = Console.ReadLine();
            string insertQuery = "insert into dbo.Repair(Repair_Id,Inventory_Id,WhatToRepair) values ('" + Repair_Id + "','" + Inventory_Id + "','" + WhatToRepair + "')";
            return insertQuery;
        }
        //this is the command to delete the vehicle from repair
        public string VehicleRepairDelete()
        {

            Console.WriteLine("Enter the id of the entry to be removed");
            Repid = int.Parse(Console.ReadLine());
            String deleteQuery = "DELETE FROM Repair WHERE Repair_Id = " + Repid + "";
            return deleteQuery;
        }
        //this is the command to update vehicle for repair
        public string VehicleRepairUpdate()
        {

            Console.WriteLine("Enter the id of the entry to be Updated");
            Repid = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the name you would like to change");
            WhatToRepair = Console.ReadLine();
            String updateQuery = "UPDATE Repair SET WhatToRepair = '" + WhatToRepair + "' WHERE Repair_Id = " + Repid + "";
            return updateQuery;
        }
    }
}
